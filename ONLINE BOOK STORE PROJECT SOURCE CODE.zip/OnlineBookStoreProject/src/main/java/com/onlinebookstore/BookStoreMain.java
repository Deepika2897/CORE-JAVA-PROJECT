/**
 ****************************** CORE JAVA PROJECT ***********************************************
 ************************CSR CAPGEMINI TRAINING PROJECT******************************************
 *******************EDUBRIDGE INDIA PRIVATE LIMITED**********************************************
 *****************PROJECT TITLE:ONLINE BOOK STORE************************************************
 ***************@DONEBY S.DEEPIKA****************************************************************
 ************@UNDER THE GUIDANCE OF THE TRAINER-MRS.INDRAKKA MALLI*******************************
 */


package com.onlinebookstore;

import java.util.Scanner;

public class BookStoreMain {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true)
		{

			System.out.println("********Welcome To Online Book Store************");
			System.out.println("1.ADMIN");
			System.out.println("2.USER");
			System.out.println("3.EXIT");
			System.out.println("enter your choice:");
			int in=sc.nextInt();
			switch(in)
			{
			case 1:
				while(true)
				{
					
					System.out.println("1.ADMIN LOGIN");
					System.out.println("2.EXIT");
					
					System.out.println("enter your choice:");
					int ch=sc.nextInt();
					switch(ch)
					{
					
					case 1:System.out.println("LOGIN ");
					//perform the login operation
					BookStoreProcess.adminLoginInfo();
					break;
					
					case 2:System.out.println("EXIT");
					break;
					
					default:System.out.println("invalid input");
					}
					//for repetition purpose
					System.out.println("do you want to continue the admin registration or login process yes/no");
					//getting input
					String input=sc.next();
					if(input.equalsIgnoreCase("no"))//comparing input with the condition
					{
						break;
					}
				}
                 break;
			
			
			case 2:
				while(true)
				{
					System.out.println("1.USER REGISTRATION");
					System.out.println("2.USER LOGIN");
					
					System.out.println("enter your choice:");
					int ch=sc.nextInt();
					switch(ch)
					{
					case 1:System.out.println("REGISTRATION");
					//perform the registration operation
					BookStoreProcess.userRegistration();   
					break;
					case 2:System.out.println("LOGIN");
					//perform the login operation
					BookStoreProcess.userLogin();
					break;
					
					default:System.out.println("invalid input");
					}
					//for repetition purpose
					System.out.println("do you want to continue the user registration or login process yes/no");
					//getting input
					String input=sc.next();
					if(input.equalsIgnoreCase("no"))//comparing input with the condition
					{
						break;
					}
				}
                 break;
			case 3:
				break;

				default:System.out.println("invalid input");
				//for repetition purpose
				System.out.println("do you want to continue the admin or user process yes/no");
				//getting input
				String input=sc.next();
				if(input.equalsIgnoreCase("no"))//comparing input with the condition
				{
					break;
				}}break;

		}
	}
}

	


