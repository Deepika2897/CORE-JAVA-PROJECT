package com.onlinebookstore;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnect {

	//driver
		static String driver="com.mysql.cj.jdbc.Driver";
		
		//here the databases name is OnlineBookStore
		//port number is 3306

		static String url="jdbc:mysql://localhost:3306/OnlineBookStore";
		//my sql username
		static String username="root";
		//my sql password
		static String password="root";
		static Connection con;
		public static Connection getconnection()
		{
			try
			{
				//loading driver
				Class.forName(driver);
				//using this arguments building the connection betweeen java and sql
				con=DriverManager.getConnection(url, username, password);
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return con;
			
		}
		

	}

