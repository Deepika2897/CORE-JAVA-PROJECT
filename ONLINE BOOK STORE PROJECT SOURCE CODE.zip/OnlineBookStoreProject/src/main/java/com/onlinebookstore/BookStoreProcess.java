/**
 * This class perform the operations are
 * 1.Admin Login
 *Viewing the book
 *Inserting the book
 *Updating the book
 *Deleting the book
 *viewing the customer order details
 *viewing the customer personal details
 * 2.User Registration
 * 4.User login
 *Viewing the book
 *Purchasing the book
 *Doing payment
 * 5.Displaying customer order details for the user
 * 6.Book cancellation
 **/



package com.onlinebookstore;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;


//these are the static variables

public class BookStoreProcess {
	static Connection con=null;
	static Scanner sc=new Scanner(System.in);
	static PreparedStatement pst=null;
	static ResultSet rst=null;
	static String emailId;
	static String username;
	static String password;
	static int choice;
	static int bookId;
	static String bookName;
	static String category;
	static String authorName;
	static int bookPrice;
	static int quantity;
	static int custId;
	static String customerName;
	static int quan;
	static int totalprice;

	//ADMIN LOGIN MODULE

	/*
	 * For this admin login process in the back end we had created one user name and password in the table called Admin Registration
	 * 
	 * That user name and pass word can be used to login in the admin login module
	 * 
	 * If the login process get successful means admin can perform all the operations
	 * 
	 * 
	 */



	public static void adminLoginInfo() 
	{
		try 
		{
			con=DbConnect.getconnection();
			//checking user name and pass word
			while(true)
			{
				System.out.println("Enter The UserName");
				username=sc.next();
				System.out.println("Enter The PassWord");
				password=sc.next();

				String checkusername="select* from admin_registration where username=?";
				pst=con.prepareStatement(checkusername);
				pst.setString(1,username);
				rst=pst.executeQuery();
				if(rst.next())
				{
					String checkpass="select * from admin_registration where password =? ";
					pst=con.prepareStatement(checkpass);
					pst.setString(1,password);
					rst=pst.executeQuery();
					if(rst.next())
					{
						System.out.println("Login successfull");
						System.out.println("1.viewing books");
						System.out.println("2.adding books");
						System.out.println("3.updating books");
						System.out.println("4.Deleting books");
						System.out.println("5.Viewing Customer order details");
						System.out.println("6.viewing customers personal details");

						System.out.println("Enter Your choice...");
						int ch1=sc.nextInt();
						switch(ch1)
						{
						case 1:System.out.println("You had the choosen book viewing process");
						//perform the book display process
						BookStoreProcess.viewBookInfo();
						break;
						case 2:System.out.println("you had choosen book adding Process");
						//perform the book insert operation
						BookStoreProcess.insertBookInfo();
						break;
						case 3:System.out.println("you had choosen updating process");
						//perform the book update operation
						BookStoreProcess.updateBookInfo();
						break;
						case 4:System.out.println("You had choosen book deleting Process");
						//perform the book deleting operation
						BookStoreProcess.deleteBookInfo();


						case 5:System.out.println("You had choosen Customer order viewing process");
						//performs the customers order display process
						BookStoreProcess.viewCustomerOrderInfo();
						break;
						case 6:System.out.println("You had choosen  Delivery Details of Customer process ");
						//performs the customers personal info process
						BookStoreProcess.viewCustomerDeliveryDetailsInfo();


						break;
						default: System.out.println("Invalid Choice");
						break;
						}break;
					}
					else
					{
						System.out.println("Invalid PassWord");
						break;
					}
				}
				else
				{
					System.out.println("Invalid User Name");

				}
				System.out.println("If You Are Already REGISTERED Then Go for once more chance");
				System.out.println("Otherwise Go for REGISTRATION");
				System.out.println("Do you want to go for ONE MORE CHANCE yes/no");
				//ALREADY REGISTERED THEN GIVING ONE MORE CHANCE
				String input=sc.next();
				if(input.equalsIgnoreCase("no"))//comparing input with the condition
				{
					break;
				}
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//ADMIN VIEW BOOK INFORMATION MODULE

	private static void viewBookInfo() {
		try
		{
			con=DbConnect.getconnection();
			String sqldis="select *from BookStore";
			pst=con.prepareStatement(sqldis);
			rst=pst.executeQuery();
			System.out.println("id\t\tcategory\t\tbookname\t\tauthorName\tprice\t\tquantity");
			while(rst.next())
			{
				System.out.println(rst.getInt(1)+"\t"+rst.getString(2)+"\t\t"+rst.getString(3)+"\t\t"+rst.getString(4)+"\t\t"+rst.getInt(5)+"\t\t\t\t"+rst.getInt(6));
			}	


		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//ADMIN INSERT BOOK INFORMATION MODULE 


	private static void insertBookInfo() {
		try
		{
			con=DbConnect.getconnection();
			System.out.println("Enter the BookName:");
			bookName=sc.next();
			String sql = "select *from BookStore where BookName=?";
			pst=con.prepareStatement(sql);
			pst.setString(1,bookName);
			rst=pst.executeQuery();
			if(!rst.next())
			{
				System.out.println("Enter the BookId");
				bookId=sc.nextInt();
				System.out.println("Enter the category");
				category=sc.next();
				System.out.println("Enter the Bookname");
				bookName=sc.next();
				System.out.println("Enter the AuthorName");
				bookName=sc.next();
				System.out.println("Enter the BookPrice");
				bookPrice=sc.nextInt();
				System.out.println("Enter the quantity");
				quantity =sc.nextInt();
				String sqlins="insert into BookStore values(?,?,?,?,?,?)";
				pst=con.prepareStatement(sqlins);
				pst.setInt(1, bookId);
				pst.setString(2,category);
				pst.setString(3, bookName);
				pst.setString(4, authorName);
				pst.setInt(5,bookPrice);
				pst.setInt(6, quantity);
				int i=pst.executeUpdate();
				if(i>0)
				{
					System.out.println("Inserted successfully");
				}
			}
			else
			{
				System.out.println("enter the correct fields");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//ADMIN UPDATE BOOK INFORMATION MODULE

	private static void updateBookInfo() {
		try
		{
			con=DbConnect.getconnection();
			System.out.println("Enter the BookId to update record:");
			bookId=sc.nextInt();
			String selbid="select *from BookStore where BookId=?";
			pst=con.prepareStatement(selbid);
			pst.setInt(1, bookId);
			rst=pst.executeQuery();


			if(rst.next())
			{
				while(true)
				{

					System.out.println("which field do you want to update");
					System.out.println("1.Update only BookName");
					System.out.println("2.Update only Bookprice");
					System.out.println("3.Update only quantity");
					System.out.println("4.Update  Bookname,BookPrice,Quantity");
					System.out.println("5.exit");
					System.out.println("Enter the choices");
					int choice=sc.nextInt();
					switch(choice)
					{
					case 1:
						System.out.println("Enter the Bookname to change");
						bookName=sc.next();
						String upd="update BookStore set bookname=? where bookid=?";
						pst=con.prepareStatement(upd);
						pst.setString(1,bookName);
						pst.setInt(2,bookId);
						int i=pst.executeUpdate();
						if(i>0)
						{
							System.out.println("Record updated");
						}
						break;
					case 2:
						System.out.println("Enter the Bookprice to change");
						bookPrice=sc.nextInt();
						String updpri="update BookStore set bookprice=? where bookname=?";
						pst=con.prepareStatement(updpri);
						pst.setInt(1, bookPrice);
						pst.setString(2, bookName);
						int j=pst.executeUpdate();
						if(j>0)
						{
							System.out.println("Record updated");
						}
						break;
					case 3:
						System.out.println("Enter the quantity to change");
						quantity=sc.nextInt();
						String updquan="update BookStore set quantity=? where bookname=?";
						pst=con.prepareStatement(updquan);
						pst.setInt(1, quantity);
						pst.setString(2, bookName);
						int k=pst.executeUpdate();
						if(k>0)
						{
							System.out.println("Record updated");
						}
						break;
					case 4: 
						System.out.println("Enter the Bookname to change");
						bookName=sc.next();
						System.out.println("Enter the Bookprice to change");
						bookPrice=sc.nextInt();
						System.out.println("Enter the Quantity to change");
						quantity=sc.nextInt();
						String updall="update BookStore set bookname=?,bookprice=?,quantity=? where bookid=?";
						pst=con.prepareStatement(updall);
						pst.setString(1, bookName);
						pst.setInt(2, bookPrice);
						pst.setInt(3, quantity);
						pst.setInt(4, bookId);
						int l=pst.executeUpdate();
						if(l>0)
						{
							System.out.println("Record updated");
						}
						break;
					case 5:
						break;
					default:System.out.println("Invalid input");
					}
					System.out.println("Dou you want to update again-yes/no");
					String input=sc.next();
					if(input.equalsIgnoreCase("no"))
					{
						break;
					}
				}}
			else {
				System.out.println(bookId+ "id not found");

			}
		}


		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//ADMIN DELETING BOOK INFORMATION MODULE

	private static void deleteBookInfo() {
		try
		{
			con=DbConnect.getconnection();
			System.out.println("Enter the BookId:");
			bookId=sc.nextInt();
			String sql="select * from BookStore where bookid=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, bookId);
			rst=pst.executeQuery();
			if(rst.next())
			{
				String del="delete from BookStore where bookid=?";
				pst=con.prepareStatement(del);
				pst.setInt(1, bookId);
				int i=pst.executeUpdate();
				if(i>0)
				{
					System.out.println("Record is deleted");   
				}
			}
			else {
				System.out.println("Record is not found");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//ADMIN VIEW CUSTOMER ORDER INFORMATION MODULE 

	private static void viewCustomerOrderInfo() {
		// TODO Auto-generated method stub
		try
		{
			con=DbConnect.getconnection();
			String sqlorderdis="select *from CustomerOrderDetails";
			pst=con.prepareStatement(sqlorderdis);
			rst=pst.executeQuery();
			System.out.println("Id\t\tCategory\t\tBookName\t\tAuthorName\t\tbookPrice\t\tquantity\t\tcustId\t\ttotalprice");
			while(rst.next())
			{
				System.out.println(rst.getInt(1)+"\t"+rst.getString(2)+"\t"+rst.getString(3)+"\t"+rst.getString(4)+"\t"+rst.getInt(5)+"\t"+rst.getInt(6)+"\t"+rst.getInt(7)+"t"+rst.getInt(8));

			}	


		}catch(Exception e)
		{
			e.printStackTrace();
		}





	}
	//_______________________________________________________________________________________________________________________________________________________________________________________________________________

	//ADMIN VIEW CUSTOMER PERSONAL INFORMATION MODULE

	private static void viewCustomerDeliveryDetailsInfo() {
		// TODO Auto-generated method stub


		// TODO Auto-generated method stub
		try
		{
			con=DbConnect.getconnection();
			String deliverydetail="select *from DeliveryDetails";
			pst=con.prepareStatement(deliverydetail);
			rst=pst.executeQuery();
			System.out.println("Id\t\tcustname\t\tmobno\t\tdoorno\t\tstreetname\t\tlocation\t\tpincode");
			while(rst.next())
			{
				System.out.println(rst.getInt(1)+"\t"+rst.getString(2)+"\t"+rst.getInt(3)+"\t"+rst.getInt(4)+"\t"+rst.getString(5)+"\t"+rst.getString(6)+"\t"+rst.getInt(7));

			}	


		}catch(Exception e)
		{
			e.printStackTrace();
		}



	}

	//___________________________________________________________________________________________________________________________________________________________________________________________________________________	

	// USER REGISTRATION MODULE

	/**
	 * User  Registration
	 * 
	 * Registration Modules-> User Registration() ->It takes informations from customer and saves in a database.
	 *   
	 *   ->first it checks the registration is already done by the same mail id or not.
	 *    if it is not then ask further information regarding the registration...
	 *    
	 *    ->User name and password...while setting password confirmation also done.
	 *    
	 *    
	 *                          
	 * */          

	public static void userRegistration() {
		try 
		{
			con=DbConnect.getconnection();
			System.out.println("enter your email id");
			emailId=sc.next();
			//fetching email id from user registration
			String selemail="select * from user_registration where emailid=?";
			pst=con.prepareStatement(selemail);
			pst.setString(1, emailId);
			rst=pst.executeQuery();
			if(!rst.next())
			{
				System.out.println("Enter Your User Name");
				username=sc.next();
				System.out.println("Enter Your Pass Word");
				password=sc.next();
				while(true) 
				{
					System.out.println("Re Enter the Pass Word");
					String repass=sc.next();
					//Checking both passwords are same or not
					if(repass.equals(password))
					{
						String regsql="insert into user_registration values(?,?,?,?)";
						pst=con.prepareStatement(regsql);
						pst.setString(1, emailId);
						pst.setString(2, username);
						pst.setString(3, password);
						pst.setString(4, repass);
						int i=pst.executeUpdate();
						if(i>0)
						{
							System.out.println("REGISTERED SUCCESSFULLUY...");
							System.out.println("THANK YOU FOR YOUR REGISTRATION...");
							break;
						}}
					else{
						System.out.println("recheck the re entered pass word");
					}}//while loop closing
			}//if statement closing
			else
			{
				System.out.println("This Email id already exists try with different name");}
		}catch (Exception e) 
		{
			e.printStackTrace();

		}}


	//----------------------------------------------------------------------------------------------------------------------------------------------------

	//USER LOGIN  MODULE

	/*
	 * In this User login Module in  the back end we had created one user name and password for the user
	 * 
	 * That user name and pass word can be used to login in the User login module
	 * 
	 * If the login process get successful means user can perform  all the operations
	 * 
	 */


	public static void userLogin() {
		try
		{
			con=DbConnect.getconnection();
			//checking user name and pass word
			while(true)
			{
				System.out.println("Enter The UserName");
				username=sc.next();
				System.out.println("Enter The PassWord");
				password=sc.next();

				String checkusername="select* from user_registration where username=?";
				pst=con.prepareStatement(checkusername);
				pst.setString(1,username);
				rst=pst.executeQuery();
				if(rst.next())
				{
					String checkpass="select * from user_registration where password =? ";
					pst=con.prepareStatement(checkpass);
					pst.setString(1,password);
					rst=pst.executeQuery();
					if(rst.next())
					{
						System.out.println("LOGIN SUCCESSFULL");
						while(true)
						{


							System.out.println("1.viewbooks");
							System.out.println("2.BookCancellation");

							System.out.println("Enter Your choice...");
							int ch1=sc.nextInt();
							switch(ch1)
							{
							case 1:System.out.println("You had  choosen  viewing the book Process");
							//perform the book order operation
							BookStoreProcess.BookView();
							break;
							case 2:System.out.println("You had choosen the book cancellation process");
							//perform the book cancel operation
							BookStoreProcess.BookCancellation();
							break;



							default: System.out.println("Invalid Choice");

							}
							System.out.println("Do you want to continue the userprocess-yes/no");
							String input=sc.next();
							if(input.equalsIgnoreCase("no"))
							{
								break;
							}

						}

					}

					else
					{
						System.out.println("Invalid PassWord");
						break;
					}
				}
				else
				{
					System.out.println("Invalid User Name");

				}
				System.out.println("If You Are Already REGISTERED Then Go for once more chance");
				System.out.println("Otherwise Go for REGISTRATION");
				System.out.println("Do you want to go for ONE MORE CHANCE yes/no");
				//ALREADY REGISTERED THEN GIVING ONE MORE CHANCE
				String input=sc.next();
				if(input.equalsIgnoreCase("no"))//comparing input with the condition
				{
					break;
				}
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//FOR USER PURPOSE.....BOOK VIEWING PROCESS MODULE IN THE BOOK STORE 

	/**
	 * In this book viewing process user can see the whole books and book details which are available in the Book Store
	 * 
	 * when the user had seen the books if they decided to purchase then they can go for book purchase module.
	 */

	public static void BookView() {

		try
		{
			con=DbConnect.getconnection();
			String sqldis="select *from BookStore";
			pst=con.prepareStatement(sqldis);
			rst=pst.executeQuery();
			System.out.println("id\t\tcategory\t\tbookname\t\tauthorName\tprice\t\tquantity");
			while(rst.next())
			{
				System.out.println(rst.getInt(1)+"\t"+rst.getString(2)+"\t\t"+rst.getString(3)+"\t\t"+rst.getString(4)+"\t\t"+rst.getInt(5)+"\t\t\t\t"+rst.getInt(6));
			}	
			System.out.println("Do you want to order-yes/no");
			String input=sc.next();
			if(input.equalsIgnoreCase("yes"))
			{
				System.out.println("You had choosen  purchasing the book Process");
				//perform the book canceling operation
				BookStoreProcess.BookPurchase();


			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//FOR USER PURPOSE-> BOOK PURCHASING MODULE 

	public static void BookPurchase() {

		try {
			while(true)
			{
				con=DbConnect.getconnection();
				System.out.println("Enter the bookId:");
				bookId=sc.nextInt();
				String sql="select *from bookStore where bookId=?";
				pst=con.prepareStatement(sql);
				pst.setInt(1, bookId);
				rst=pst.executeQuery();
				if(rst.next())
				{
					System.out.println("Place your order");
					//entering details for delivery
					System.out.println("Enter your customerId:");
					int custId=sc.nextInt();
					System.out.println("Enter your customerName:");
					String customerName=sc.next();
					//System.out.println("Enter the BookQuantity:");
					//quantity=sc.nextInt();
					System.out.println("Enter Your MobileNo:");
					String mobno=sc.next();
					System.out.println("Enter Your full Address:");
					System.out.println("Door No:");
					String doorno=sc.next();
					sc.nextLine();
					System.out.println("Enter the Street Name:");
					String streetname=sc.nextLine();
					System.out.println("Enter Your Location:");
					String location=sc.nextLine();
					System.out.println("Enter the Pincode:");
					int pincode=sc.nextInt();
					String sqlper="insert into DeliveryDetail values(?,?,?,?,?,?,?)";
					pst=con.prepareStatement(sqlper);
					pst.setInt(1, custId);
					pst.setString(2, customerName);
					//pst.setInt(3, quantity);
					pst.setString(3,mobno);
					pst.setString(4, doorno);
					pst.setString(5,streetname);
					pst.setString(6, location);
					pst.setInt(7,pincode);
					int i=pst.executeUpdate();
					if(i>0)
					{System.out.println("your order information is taken:");


					switch(bookId)
					{
					case 111:System.out.println("Your choosen this bookId"  +bookId);

					category="computer_programming";         
					bookName="Java_Complete_Reference";
					authorName="Herbert_schildt";
					bookPrice=123;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 112:System.out.println("Your choosen this bookid"+bookId);

					category=" Suspense";         
					bookName="The_Judges_House";
					authorName="Bram_Stocker";
					bookPrice=134;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;

					case 113:System.out.println("Your choosen this bookid"+bookId);

					category="Poetry";         
					bookName="Love_Poems";
					authorName="Ivo_Mosley";
					bookPrice=145;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 114:System.out.println("Your choosen this bookid"+bookId);

					category="Story";         
					bookName="Disney_Jungle_Book";
					authorName="Bernard_CornWell";
					bookPrice=250;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;



					case 115:System.out.println("Your choosen this bookid"+bookId);

					category="Crime";         
					bookName="Death_On_The_Air";
					authorName="Ngaio_Marth";
					bookPrice=350;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 116:System.out.println("Your choosen this bookid"+bookId);

					category="Dream";         
					bookName="An_Intro_To_DreamLand";
					authorName="Bhagat_Singh";
					bookPrice=345;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 117:System.out.println("Your choosen this bookid"+bookId);

					category="Awareness";         
					bookName="A_Better_India";
					authorName="Narayana_Murthy";
					bookPrice=450;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 118:System.out.println("Your choosen this bookid"+bookId);

					category="Drama";         
					bookName="A_Tale_of_Two_Cities";
					authorName="Charles_Darwin";
					bookPrice=323;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 119:System.out.println("Your choosen this bookid"+bookId);

					category="Comedy";         
					bookName="The_Dancing_Partner";
					authorName="Jerome_K_Jerome";
					bookPrice=434;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;


					case 120:System.out.println("Your choosen this bookid"+bookId);

					category="Science_Fiction";         
					bookName="The_Sirens_Of_Mars";
					authorName="Sara_Johnson";
					bookPrice=546;
					System.out.println("Enter the quantity");
					quan=sc.nextInt();
					quantity=quan;
					totalprice=bookPrice*quan;
					break;
					default:
						System.out.println("Invalid id");
					}

					String sqlins="insert into CustomerOrderDetails values(?,?,?,?,?,?,?,?)";
					pst=con.prepareStatement(sqlins);
					pst.setInt(1,bookId);
					pst.setString(2,category);
					pst.setString(3,bookName );
					pst.setString(4,authorName);
					pst.setInt(5,bookPrice);
					pst.setInt(6,quantity);
					pst.setInt(7,custId);
					pst.setInt(8, totalprice);				
					int a=pst.executeUpdate();
					if(a>0)
					{
						System.out.println("Select payment option");
						System.out.println("1.Cash on Delivery");
						System.out.println("2.Cash on Card");
						int input=sc.nextInt();

						switch(input){
						case 1:System.out.println("YOU HAD CHOOSEN CASH ON DELELIVERY OPTION...");

						System.out.println("YOUR ORDER WILL BE DISPATCH SOON....READY WITH YOU CASH INHAND....THNAK YOU!");
						break;

						case 2:System.out.println("You had choosen cash on card payment option");
						BookStoreProcess.Payment();
						break;

						}
						break;
					}

					}
					System.out.println("Do you want to order another one again-yes/no: ");
					String input=sc.next();
					if(input.equalsIgnoreCase("no"))
					{
						break;
					}
					break;
				}
				else
				{
					System.out.println("your choosen bookid is not there in the store...invalid option...so choose the correct bookid");

				}
				break;
			}}

		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	//------------------------------------------------------------------------------------------------------------------------------------------------------

	//FOR USER PURPOSE-> PAYMENT MODULE FOR AMOUNT PAY	

	private static void Payment() {

		try {
			con=DbConnect.getconnection();

			System.out.println("go for payment");
			System.out.println("enter your account number");
			int accno=sc.nextInt();
			System.out.println("enter your pin number");
			int pinno=sc.nextInt();
			String transacc="select accno from customersaccount where accno=?";
			pst=con.prepareStatement(transacc);
			pst.setInt(1, accno);
			rst=pst.executeQuery();
			if(rst.next())
			{
				String transpin="select accpin from customersaccount where accpin=?";
				pst=con.prepareStatement(transpin);
				pst.setInt(1, pinno);
				rst=pst.executeQuery();
				if(rst.next())
				{
					String balcheck="select balance from customersaccount where accno=? having balance>0";
					pst=con.prepareStatement(balcheck);
					pst.setInt(1,accno);
					rst=pst.executeQuery();
					if(rst.next())
					{
						String upd="update customersaccount set Balance=Balance-(select totalprice from customerorderdetails where custId=?) where Accno=?";
						pst=con.prepareStatement(upd);
						pst.setInt(1,custId);
						pst.setInt(2, accno);
						int Z=pst.executeUpdate();				
						if(Z>0)
						{
							System.out.println("Your payment processed:");
							String transadmin="insert into adminaccount values(?,?)";
							pst=con.prepareStatement(transadmin);
							pst.setInt(1,accno);
							pst.setInt(2,totalprice);
							int p=pst.executeUpdate();
							if(p>0)
							{
								System.out.println("Your order is confirmed");
								System.out.println("Do you want to See about your whole ORDER DETAILS ");
								String o=sc.next();
								if(o.equalsIgnoreCase("yes"))
								{
									System.out.println("Customerdetails");
									BookStoreProcess.displayCustomerOrderDetails();
								}

							}

							else
							{
								System.out.println("amount not inserted in adminaccount ");
							}
						}
						else
						{
							System.out.println("Invalid pin number");
						}
					}
					else
					{
						System.out.println("Insufficient balance");
					}

				}
				else {
					System.out.println("Account number not exists");
				}
			}}
		catch(Exception e)
		{
			e.printStackTrace();
		}}

	//----------------------------------------------------------------------------------------------------------------------------------------------------------			

	//FOR USER PURPOSE->DISPLAYING CUSTOMER ORDER DETAILS MODULE		

	public static void displayCustomerOrderDetails() {

		try 
		{ 
			con=DbConnect.getconnection();
			System.out.println("Enter your custid:");
			custId=sc.nextInt();
			String display="select * from deliverydetail where custid=?";
			pst=con.prepareStatement(display);
			pst.setInt(1,custId);
			rst=pst.executeQuery();

			if(rst.next())
			{
				System.out.println("DeliveryDetail shown"); 
				System.out.println("----------------------------------------------PERSONAL DETAILS----------------------------------------------------------------------------------------------------");
				System.out.println("___________________________________________________________________________________________________________________________________________________________________");
				System.out.println("custid\t\tcustomerName\tMobileNo\tDoorno\tStreetname\tLocation\tPincode");
				System.out.println("___________________________________________________________________________________________________________________________________________________________________ ");
				System.out.println(rst.getInt(1)+"\t\t"+rst.getString(2)+"\t\t"+rst.getString(3)+"\t"+rst.getString(4)+"\t"+rst.getString(5)+"\t\t"+rst.getString(6)+"\t\t"+rst.getInt(7));
				System.out.println("___________________________________________________________________________________________________________________________________________________________________ ");
				String orderch="select * from customerorderdetails where custid=?";
				pst=con.prepareStatement(orderch);
				pst.setInt(1, custId);
				rst=pst.executeQuery();
				while(rst.next())

				{System.out.println("OrderDetail shown"); 
				System.out.println(        ); 
				System.out.println("--------------------------ORDER DETAILS---------------------------------------------------------------------------------------------------------------------------");
				System.out.println("___________________________________________________________________________________________________________________________________________________________________");
				System.out.println("bookId\t\tcategory\t\tbookname\t\tauthorname\t\tcustid");
				System.out.println("____________________________________________________________________________________________________________________________________________________________________");
				System.out.println(rst.getInt(1)+"\t\t"+rst.getString(2)+"\t\t"+rst.getString(3)+"\t"+rst.getString(4)+"\t\t"+rst.getInt(5));
				System.out.println("_____________________________________________________________________________________________________________________________________________________________________");
				String paymentch="select * from customerorderdetails where custid=?";
				pst=con.prepareStatement(paymentch);
				pst.setInt(1, custId);
				rst=pst.executeQuery();
				while(rst.next())
				{
					System.out.println(        );
					System.out.println("-----------------------PAYMENT DETAILS--------------------------------------------------------------------------------------------------------------------------");
					System.out.println("________________________________________________________________________________________________________");
					System.out.println("custId\t\tbookprice\tquantity\ttotalprice");
					System.out.println("_________________________________________________________________________________________________________");

					System.out.println(rst.getInt(7)+"\t\t"+rst.getString(5)+"\t\t"+rst.getInt(6)+"\t\t"+rst.getInt(8)+"\t\t");
					System.out.println("__________________________________________________________________________________________________________");
					break;
				}
				}
			}
			else
			{
				System.out.println("You had given the wrong CustomerId....Please insert the correct customerId...");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	//------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//FOR USER PURPOSE-> BOOK CANCELLATION  MODULE

	public static void BookCancellation()
	{
		try
		{


			con=DbConnect.getconnection();

			System.out.println("Enter the bookId:");
			bookId=sc.nextInt();
			String sql="select *from customerorderdetails where bookId=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, bookId);
			rst=pst.executeQuery();
			if(rst.next())
			{
				System.out.println("enter your email id");
				emailId=sc.next();
				System.out.println("enter the user name");
				username=sc.next();
				System.out.println("enter the password");
				password=sc.next();
				System.out.println("enter the bookId");
				bookId=sc.nextInt();
				String chmail="select emailid from user_registration where emailid=? ";
				pst=con.prepareStatement(chmail);
				pst.setString(1,emailId);
				rst=pst.executeQuery();
				if(rst.next())
				{	
					String chuser="select username from user_registration where username=? ";
					pst=con.prepareStatement(chuser);
					pst.setString(1,username);
					rst=pst.executeQuery();
					while(rst.next())
					{	
						String chpass="select password from user_registration where password=? ";
						pst=con.prepareStatement(chpass);
						pst.setString(1,password);
						rst=pst.executeQuery();
						if(rst.next())
						{	
							String canBook="delete from customerorderdetails where BookId=? ";
							pst=con.prepareStatement(canBook);
							pst.setInt(1,bookId);
							int m=pst.executeUpdate();

							if(m>0)
							{		
								String candetail="delete from deliverydetail where custId=? ";
								pst=con.prepareStatement(candetail);
								pst.setInt(1,custId);
								int n=pst.executeUpdate();
								if(n>0)
								{
									System.out.println("Your cancellation is done");
									break;
								}}}	}}
				else
				{
					System.out.println("invalid email");
				}

			}
			else
			{
				System.out.println("your not ordered any book...");
			}


		}

		catch(Exception e) {
			e.printStackTrace();
		}}}







//-------------------------------------------------------------------------------------------------------------------------------------------